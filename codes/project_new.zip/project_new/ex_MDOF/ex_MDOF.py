import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
from scipy.signal import find_peaks
import pywt


def MDOF_wavelet(A, ksi, wn, t, Fs, B, C,f_min, f_max, threshold, print_opt):
    plt.rcParams["font.family"] = "Times New Roman"
    plt.close('all')
    wd = wn * np.sqrt(1 - ksi ** 2)
    h = np.zeros(t.shape)
    for i in range(wn.shape[0]):
        h += A[i] * np.sin(wn[i] * t) * np.exp(-ksi[i] * t * wd[i])

    # STEP1: PLOT THE TIME HISTORY
    plt.figure()
    plt.plot(t, h, 'black', linewidth=1.2)
    plt.xlabel('Time(sec)')
    plt.ylabel('x(t)')
    plt.xlim(left=0)
    plt.grid(color='gray', linestyle='--', linewidth=0.8)
    plt.title('Time History of Impulse Response')
    if print_opt in 'yes':
        plt.savefig('Time history.png', dpi=800)

    # STEP2: CWT OF THE ORIGINAL SIGNAL
    scale = np.arange(int(C*Fs/f_max), int(C*Fs/f_min), 1)
    coeff, f = pywt.cwt(h, scale, 'cmor' + str(B) + '-' + str(C), 1 / Fs)

#######################################################################################################################
    # STEP3: PLOT THE RESULTS IN TIME-FREQUENCY
    # magnitude of the cwt
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    t_new, f_new = np.meshgrid(t, f)
    surf = ax.plot_surface(t_new, f_new, abs(coeff), cmap=cm.coolwarm,
                           linewidth=0, antialiased=False)
    ax.view_init(azim=-132, elev=20)
    plt.xlabel('Time (sec)')
    plt.ylabel('Frequency (Hz)')
    ax.zaxis.set_rotate_label(False)  # disable automatic rotation
    ax.set_zlabel('Magnitude')
    plt.title('Magnitude of CWT Coefficient')
    fig.colorbar(surf, shrink=0.4, aspect=7)
    if print_opt in 'yes':
        plt.savefig('cwt magnitude.png', dpi=800)

    # phase of the cwt results
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    surf = ax.plot_surface(t_new, f_new, np.angle(coeff), cmap=cm.coolwarm,
                           linewidth=0, antialiased=False)
    ax.view_init(azim=-132, elev=20)
    plt.xlabel('Time (sec)')
    plt.ylabel('Frequency (Hz)')
    ax.zaxis.set_rotate_label(False)  # disable automatic rotation
    ax.set_zlabel("Phase")
    plt.title('Phase of CWT Coefficient')
    fig.colorbar(surf, shrink=0.4, aspect=7)
    if print_opt in 'yes':
        plt.savefig('cwt phase.png', dpi=800)

    #######################################################################################################################
    # STEP4: find the maximum
    plt.figure()
    plt.plot(f, abs(coeff[:, int(coeff.shape[1] / 2)]), color='black')
    plt.xlim(left=0, right=10)
    plt.xlabel('Frequency(Hz)')
    plt.ylabel('|W(a,b)|')
    plt.title('Instantaneous Spectrum')
    plt.grid(color='gray', linestyle='--', linewidth=0.8)
    peak, _ = find_peaks(abs(coeff[:, int(coeff.shape[1] / 2)]),
                         height=threshold * max(abs(coeff[:, int(coeff.shape[1] / 2)])), distance=20)
    # peak
    plt.plot(f[peak], abs(coeff[peak, int(coeff.shape[1] / 2)]), "x", color='red', label='local peaks')
    plt.legend()
    if print_opt in 'yes':
        plt.savefig('instantaneous spectrum.png', dpi=800)
    # peak = int(np.mean(peak))
    #######################################################################################################################

    for m in range(0,len(peak)):
        plt.figure()
        plt.plot(t, np.log(abs(coeff)[peak[m,], :]), 'black', linewidth=1.2)
        plt.grid(color='gray', linestyle='--', linewidth=1)
        plt.xlim(left=0)
        plt.xlabel('Time (sec)')
        plt.ylabel(r'$log|W(a_i, t)|$')
        if print_opt in 'yes':
            plt.savefig('log mag.png', dpi=800)

        plt.figure()
        plt.plot(t, -np.angle(coeff)[peak[m,], :], 'black', linewidth=1.2)
        plt.grid(color='gray', linestyle='--', linewidth=1)
        plt.xlim(left=0)
        plt.xlabel('Time (sec)')
        plt.ylabel(r'$\phi(a_i, t)$')
        if print_opt in 'yes':
            plt.savefig('phase.png', dpi=800)
        temp = -np.angle(coeff)[peak[m,], :]
        phase_slop = np.zeros((len(temp) - 1,))
        for i in range(0, len(temp) - 1):
            phase_slop[i,] = (temp[i + 1,] - temp[i,]) * Fs

        plt.figure()
        plt.plot(t[0:len(t) - 1, ], phase_slop)

    return coeff, f, peak, phase_slop


A = np.array([10, 9])
ksi = np.array([0.05, 0.05])
wn = np.array([10, 11])
Fs = 100
t = np.arange(0, 1000, 1) / Fs
B = 1
C = 8
f_min = 1
f_max = 20

coeff, f, peaks, phase_slop = MDOF_wavelet(A, ksi, wn, t, Fs, B, C, f_min, f_max, threshold=0.7, print_opt='yes')
