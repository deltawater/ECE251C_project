clear all; clc; close all;
% LIN SUN
% NOV. 7th, 2020
%% step 1: load the data 
station = {'lbba','lbse'};
%e stands for east, n stands for north, z stands for vertical
dir = {'e','n','z'};
path = 'D:\UCSD PhD\GeiselProject\LibraryData\ConvertedData'; date.year = '2020'; date.month = '04'; date.day = '04'; date.hour = '01';
truncate= [320000 321500+6000];
Fs = 100; % sampling rate
ucsd = structure(path, date, station, dir, truncate, Fs);
%% step 2: plot the spectrum of the signal
close all;
linewidth = 1.3;
linestyle = '-';
data_choice = {'output', 'z'};
linecolor = 'black';
% f_range = [0 40];
% print_opt = 'yes';
% analysis(ucsd, linecolor , linewidth, linestyle, data_choice, f_range, print_opt);

%% do system identification
close all; clc;

ecgsig =ucsd.output(:,1);
 t = 0:1/100:(length(ecgsig)-1)/100;
ecgsig(ecgsig<0) = 0;
figure
plot(t,ecgsig)
xlabel('Seconds')
ylabel('Amplitude')
title('Subject - MIT-BIH 200')
qrsEx = ecgsig(37.53*Fs:38.1*Fs);
[mpdict,~,~,longs] = wmpdictionary(numel(qrsEx),'lstcpt',{{'sym4',3}});


wt = modwt(ecgsig,5);
wtrec = zeros(size(wt));
wtrec(4:5,:) = wt(4:5,:);
y = imodwt(wtrec,'sym4');
y = abs(y).^2;
[qrspeaks,locs] = findpeaks(y,t,'MinPeakHeight',0.001,...
    'MinPeakDistance',0.01);
figure
plot(t,y)
hold on
plot(locs,qrspeaks,'ro')

xlabel('Seconds')
title('R Peaks Localized by Wavelet Transform with Automatic Annotations');

figure
plot(t,ecgsig,'k--')
hold on
plot(t,y,'r','linewidth',1.5)
plot(t,abs(ecgsig).^2,'b')
% set(gca,'xlim',[10.2 12])
legend('Raw Data','Wavelet Reconstruction','Raw Data Squared', ...
    'Location','SouthEast');
xlabel('Seconds')
figure()
plot(t(floor(locs*Fs)), ecgsig(floor(locs*Fs)),'o');
hold on
plot(t,ecgsig')
