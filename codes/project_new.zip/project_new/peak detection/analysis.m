classdef analysis
    properties
        structure
        FAS % FAS.f % the frequency vector; FAS.X: the fourier transform values
        spectrogram
        line % the details about the lines such as with and color
        data % the time series data to be analyzed
    end
    
    methods
        function obj = analysis(structure, linecolor, linewidth, linestyle, data_choice, frange, print_opt)
            obj.structure = structure;
            obj.line.color = linecolor;
            obj.line.width = linewidth;
            obj.line.style = linestyle;
            if data_choice{1} == 'output'
                temp = structure.output;
            elseif data_choice{1} == 'input'
                temp = structure.input;
            end
            if data_choice{2} == 'e'
                obj.data = temp(:,1);
            elseif data_choice{2} == 'n'
                obj.data = temp(:,2);
            elseif data_choice{2} == 'z'
                obj.data = temp(:,3);
            end
            %% plot the Time History
            obj.plot_time_his(print_opt);
            %% plot the Fourier Amplitude Spectrum
            [obj.FAS.f, obj.FAS.X] = obj.plot_FAS(frange, print_opt);
            %% plot the Spectrogram thru STFT
            nwin = 2^6;
            nfft = nwin;
            overlap_ratio = 0.5;
            window_type = 'hamming';
            title_name = 'Spectrogram';
            [~,~,~,~, ~] = obj.plot_spectrogram(window_type, nwin, overlap_ratio, nfft, title_name, frange, print_opt);
            %% plot the scalogram
            figure()
            wname = 'bump';
            obj.plot_scalogram(wname, frange, print_opt)
        end
        
        
        function plot_time_his(obj, plot_opt)
            Fs = obj.structure.Fs;
            t = 0:1/Fs:(length(obj.data)-1)/Fs;
            figure()
            plot(t, obj.data, 'color', obj.line.color, 'LineWidth', obj.line.width);
            xlabel('Time [sec]'); ylabel('Acceleration (m/sec^2)');
            set(gca, 'FontName', 'Times New Roman');
            grid on;
            if strcmp(plot_opt, 'yes')
                print_plot('Time History.png', 5, 3, 800)
            end
        end
        function [f, X] = plot_FAS(obj,frange, print_opt)
            figure()
            fs = obj.structure.Fs;
            linecolor = obj.line.color;
            linewidth = obj.line.width;
            linestyle = obj.line.style;
            x = obj.data;
            X = fft(x); DT=1/fs; N = length(x); T = N*DT; f= (0:1/T:0.5*(N-1)/T);
            if mod(N,2) == 0
                plot(f,abs(X(1:N/2)),'color',linecolor,'LineWidth',linewidth,'LineStyle',linestyle);
            elseif mod(N, 2) == 1
                plot(f(1:end-1),abs(X(1:(N-1)/2)),'color',linecolor,'LineWidth',linewidth,'LineStyle',linestyle);
            end
            xlabel('Frequency [Hz]'); ylabel('FAS'),grid on;
            set(gca, 'fontname','Times New Roman');
            
            if nargin == 2
                xlim([frange(1) frange(2)])
            end
            if strcmp(print_opt, 'yes')
                print_plot('FAS.png',5, 3, 800);
            end
        end
        
        function [gap,t_new,t_missing,power_new, power] = plot_spectrogram(obj, window_type, nwin, overlap_ratio, nfft, title_name, frange, print_opt)
            fs = obj.structure.Fs;
            data = [obj.data (0:1/fs:(length(obj.data)-1)/fs)'];
            t_unit = 'sec';
            t_start = 0;
            t_end = (length(data)-1)/fs;
            % this function is to plot the spectrogram for the data,
            % which is missing some datas.
            % LIN SUN, University of California, San Diego
            % March 29th, 2020
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Input:
            % data: the first column is the values(displ., accel. ...), the second
            % column is the times series;
            % window_type: the type of window to choose while computing the stft;
            % overlap_ratio: the overlap ratio while computing the stft;
            % nfft: the number of fourier transform while computing the stft;
            % fs: the sampling frequency;
            % gap: gap.index: where the data is missing; gap.len: how many datas are
            % missing in the interval;
            
            %% Output:
            % the plot of the spectrogram
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %% find data gap
            [gap] = find_data_gap(data,fs,t_start,t_end);
            %% remove the mean
            data(:,1) = data(:,1)-mean(data(:,1));
            %% divide the data into different segments of data
            if length(gap.len) ~= 0
                sub_index = gap.index;
                if gap.index(1) ~= 1
                    sub_index = [1; gap.index;];
                end
                
                if gap.index(end) ~= size(data,1)
                    sub_index = [sub_index; size(data,1);];
                end
                
                for i = 1:length(sub_index)-1
                    if i == 1
                        sub_data{i} = data(sub_index(i):sub_index(i+1),:);
                    else
                        sub_data{i} = data(sub_index(i)+1:sub_index(i+1),:);
                    end
                end
            end
            
            %% choose the window type
            switch window_type
                case 'hanning'
                    window = hann(nwin);
                case 'hamming'
                    window = hamming(nwin);
                case 'triangle'
                    window = triang(nwin);
                case 'rectangular'
                    window = rectwin(nwin);
                case 'bartlett'
                    window = bartlett(nwin);
            end
            %%  compute the stft for each segment
            noverlap = overlap_ratio*nwin;
            if length(gap.len) ~= 0
                for i = 1:length(sub_data)
                    [M{i}, f{i}, t{i}] = stft(sub_data{i}(:,1),fs,'Window',window,'OverlapLength',noverlap,'FFTLength',nfft);
                    power{i} = 20*log10(M{i}.*conj(M{i}));
                end
                %% compute the missing data's power and time series
                for i = 1:length(gap.index)
                    power_missing{i} = pi*ones(length(f{1}),2);
                    t_missing{i} = [data(gap.index(i),2) data(gap.index(i)+1,2)];
                end
                
                for i = 1:length(sub_data)
                    y = sub_data{i}(:,2);
                    t_original{i} = [(y(end)-y(1))/(length(t{i})-1)*(0:length(t{i})-1)+y(1)];
                end
                
                %% Assemble the sub-power and sub-time into global vector
                power_new = [];
                t_new = [];
                
                for i = 1:length(gap.index)
                    if (gap.index(1) == 1) && (gap.index(end) ~= length(data))
                        power_new = [power_new  power_missing{i} power{i}];
                        t_new = [t_new t_missing{i} t_original{i}];
                        
                    elseif (gap.index(1) ~= 1) && (gap.index(end) ~= length(data))
                        power_new = [power_new  power{i} power_missing{i}];
                        t_new = [t_new  t_original{i} t_missing{i}];
                        if i == length(gap.index)
                            power_new = [power_new power{i+1}];
                            t_new = [t_new t_original{i+1}];
                        end
                        
                        
                    elseif (gap.index(1) == 1) && (gap.index(end) == length(data))
                        
                        if i ~= length(gap.index)
                            power_new = [power_new  power_missing{i} power{i}];
                            t_new = [t_new  t_missing{i} t_original{i}];
                        elseif i == length(gap.index)
                            power_new = [power_new power_missing{i}];
                            t_new = [t_new t_missing{i}];
                        end
                        
                    end
                end
                
                %% plot the spectrogram
                figure()
                power_new(power_new == pi) = NaN; % remove the missing data's power
                surf(t_new',f{1},power_new,'edgecolor','none');
                
                shading flat;
                axis tight;
                view(0,90);
                colormap default
                hcol = colorbar;
                set(hcol, 'FontName', 'Times New Roman', 'FontSize', 8);
                xlabel(sprintf('Time [%s]',t_unit));
                ylabel('Frequency [Hz]');
                zlabel('Power [dB]');
                ylim([frange(1) frange(2)])
                set(gca, 'fontname', 'times new roman')
            elseif length(gap.len) == 0
                [M, f, t] = stft(data(:,1),fs,'Window',window,'OverlapLength',noverlap,'FFTLength',nfft);
                power = 20*log10(M.*conj(M));
                figure()
                surf(t',f,power,'edgecolor','none');
                t_new = t;
                t_missing = []; power_new = power;
                shading flat;
                axis tight;
                view(0,90);
                colormap default
                hcol = colorbar;
                set(hcol, 'FontName', 'Times New Roman', 'FontSize', 8);
                xlabel(sprintf('Time [%s]',t_unit));ylabel('Frequency [Hz]'); zlabel('Power [dB]'); title(title_name);
                ylim([frange(1) frange(2)])
                set(gca, 'fontname', 'times new roman')
            end
            
            
            function [gap] = find_data_gap(data, fs, x_start, x_end)
                % this code is to find where some datas are missing, and how big the gap is
                % LIN SUN
                % 2020/03/28 UNIVERSITY OF CALIFORNIA, SAN DIEGO
                %% Input:
                %data: the second column is time, the first column is the accleration
                %(but can be used in any similar like displ. ...)
                %x_end: the supposed last x value
                %x_start: the supposed first x Value
                
                %% output
                % gap: data structure to store the info about the gap
                % gap.index: where the data is missing
                % gap.len: the gap length
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %% Initialize
                gap.index = [];
                gap.len = {};
                %% check whether the starting data is missing
                if abs((data(1,2)-x_start)) > (1/fs)*1.003
                    gap.index = 1;
                    gap.len{1} = length((x_start:1/sample_freq:(data(1,2)-1/sample_freq))');
                end
                
                %% check whether the middle data is missing
                %% check whether there are some data missing in the middle
                for i = 1:length(data)-1
                    if round((data(i+1,2)-data(i,2))*fs) ~= 1
                        %find where the data is missing
                        gap.index = [gap.index; i;];
                        lost_data_index = i+1;
                        %linear interpolation
                        x = [data(lost_data_index-1,2) data(lost_data_index,2)];
                        x_new = x(1):1/fs:x(2);
                        gap.len{length(gap.index)} = length(x_new) - 2;
                        
                    end
                end
                
                %% check whether the last data is missing
                if abs(data(end,2)-(x_end)) > 1/fs
                    gap.index = [index; size(data,1);];
                    gap.len{length(gap.index)} = length(data(end,2):1/fs:(x_end));
                end
            end
            if strcmp(print_opt, 'yes')
                print_plot('spectrogram.png', 5, 3, 800);
            end
        end
        function plot_scalogram(obj, wname, frange, print_opt)
            t = 0:1/obj.structure.Fs:(length(obj.data)-1)/obj.structure.Fs;
            [wt, f, ~] = cwt(obj.data, wname, obj.structure.Fs);
            surf(t,f,abs(wt).^2);
            shading flat;
            axis tight;
            view(0,90);
            colormap default
            hcol = colorbar;
            set(hcol, 'FontName', 'Times New Roman', 'FontSize', 8);
            set(gca, 'FontName', 'Times New Roman', 'YScale', 'Linear');
            xlabel('Time [sec]');
            ylabel('Frequency [Hz]');
            zlabel('Magnitude');
            ylim([frange(1) frange(2)])
            set(gca, 'YScale', 'linear')
            if strcmp(print_opt, 'yes')
                print_plot('scalogram.png', 5, 3, 800);
            end
        end
    end
end

