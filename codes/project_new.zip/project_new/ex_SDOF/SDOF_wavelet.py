import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
# from system_ID.DetectLocalPeak import DetectLocalPeak
from scipy.signal import find_peaks
import pywt



def SDOF_wavelet(A, ksi, wn, t, Fs, B, C, scale, threshold, print_opt):
    plt.rcParams["font.family"] = "Times New Roman"
    wd = wn * np.sqrt(1 - ksi ** 2)
    h = A * np.sin(wn * t) * np.exp(-ksi * t * wd)

    # STEP1: PLOT THE TIME HISTORY
    plt.figure()
    plt.plot(t, h, 'black', linewidth=1.2)
    plt.xlabel('Time(sec)')
    plt.ylabel('x(t)')
    plt.xlim(left = 0)
    plt.grid(color='gray', linestyle='--', linewidth=0.8)
    plt.title('Time History of Impulse Response')
    if print_opt in 'yes':
        plt.savefig('Time history.png', dpi = 800)

    # STEP2: CWT OF THE ORIGINAL SIGNAL
    coeff, f = pywt.cwt(h, scale, 'cmor'+str(B)+'-'+str(C), 1 / Fs)
#######################################################################################################################
    # STEP3: PLOT THE RESULTS IN TIME-FREQUENCY
    # magnitude of the cwt
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    t_new, f_new = np.meshgrid(t, f)
    surf = ax.plot_surface(t_new, f_new, abs(coeff), cmap=cm.coolwarm,
                           linewidth=0, antialiased=False)
    ax.view_init(azim=-132, elev=20)
    plt.xlabel('Time (sec)')
    plt.ylabel('Frequency (Hz)')
    ax.zaxis.set_rotate_label(False)  # disable automatic rotation
    ax.set_zlabel('Magnitude')
    plt.title('Magnitude of CWT Coefficient')
    fig.colorbar(surf, shrink=0.4, aspect=7)
    if print_opt in 'yes':
        plt.savefig('cwt magnitude.png', dpi=800)

    # phase of the cwt results
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    surf = ax.plot_surface(t_new, f_new, np.angle(coeff), cmap=cm.coolwarm,
                           linewidth=0, antialiased=False)
    ax.view_init(azim=-132, elev=20)
    plt.xlabel('Time (sec)')
    plt.ylabel('Frequency (Hz)')
    ax.zaxis.set_rotate_label(False)  # disable automatic rotation
    ax.set_zlabel("Phase")
    plt.title('Phase of CWT Coefficient')
    fig.colorbar(surf, shrink=0.4, aspect=7)
    if print_opt in 'yes':
        plt.savefig('cwt phase.png', dpi=800)

#######################################################################################################################
    # STEP4: find the maximum
    # j, i = DetectLocalPeak(abs(coeff), max(abs(coeff))*0.1, neighborhood_size=3)
    plt.figure()
    plt.plot(f, abs(coeff[:, int(coeff.shape[1] / 2)]), color='black')
    plt.xlim(left=0)
    plt.xlabel('Frequency(Hz)')
    plt.ylabel('|W(a,b)|')
    plt.title('Instantaneous Spectrum')
    plt.grid(color='gray', linestyle='--', linewidth=0.8)
    peak, _ = find_peaks(abs(coeff[:, int(coeff.shape[1] / 2)]), height=threshold * max(abs(coeff[:, int(coeff.shape[1] / 2)])))
    plt.plot(f[peak], abs(coeff[peak, int(coeff.shape[1] / 2)]), "x", color='red', label='local peaks')
    plt.legend()
    if print_opt in 'yes':
        plt.savefig('instantaneous spectrum.png', dpi=800)
    peak = int(np.mean(peak))
#######################################################################################################################
    plt.figure()
    plt.plot(t, np.log(abs(coeff)[peak, :]), 'black', linewidth=1.2)
    plt.grid(color='gray', linestyle = '--', linewidth=1)
    plt.xlim(left=0)
    plt.xlabel('Time (sec)')
    plt.ylabel(r'$log|W(a_i, t)|$')
    plt.title('logarithm of Absolute Values of Maginitude')
    if print_opt in 'yes':
        plt.savefig('log mag.png', dpi=800)

    plt.figure()
    plt.plot(t, -np.angle(coeff)[peak, :], 'black', linewidth=1.2)
    plt.grid(color='gray', linestyle='--', linewidth=1)
    plt.xlim(left=0)
    plt.xlabel('Time (sec)')
    plt.ylabel(r'$\phi(a_i, t)$')
    plt.title('Phase of the CWT Coefficient')
    if print_opt in 'yes':
        plt.savefig('phase.png', dpi=800)
    temp = -np.angle(coeff)[peak, :]
    phase_slop = np.zeros((len(temp)-1, ))
    for i in range(0,len(temp)-1):
        phase_slop[i,] = (temp[i+1,]-temp[i,])*Fs

    plt.figure()
    plt.plot(t[0:len(t)-1,], phase_slop)

    return coeff, f, peak, phase_slop


A = 10
ksi = 0.05
wn = 10
Fs = 100
t = np.arange(0, 1000, 1)/Fs
B = 1
C = 1
scale = np.arange(4, 400, 1)

coeff, f, peaks, phase_slop = SDOF_wavelet(A, ksi, wn, t, Fs, B, C, scale, threshold=0.8, print_opt='yes')