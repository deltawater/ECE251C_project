classdef structure
    properties
        path % the path to load the data
        input % lbba
        output
        Fs
        date % which date to use the data
        truncate
        station
        dir
    end
    
    methods
        function obj = structure(path, date, station, dir, truncate, Fs)
            obj.path = path;
            obj.date = date;
            obj.station = station;
            obj.truncate = truncate;
            obj.dir = dir;
            [obj.input, obj.output] = obj.load_data();
            obj.Fs = Fs;
        end
        function [input, output] = load_data(obj)
            path = obj.path;
            station = obj.station;
            direction = obj.dir;
            date = obj.date;
            truncate = obj.truncate;
            
            %% check the input argument
            year = date.year; month = date.month; day = date.day; hour = date.hour;
            fields = fieldnames(date);
            for i = 1:length(fields)
                if ~ischar(date.(fields{i}))
                    disp('The date type should be a char')
                end
            end
            %%
            data = cell(length(station), length(direction));
            for i = 1:length(station)
                for j = 1:length(direction)
                    temp = load([path '/' ...
                        station{i} '_' direction{j} '_' year '-' month '-' day '-' hour '.dat']);
                    temp = temp(truncate(1):truncate(2),:);
                    data{i,j} = temp(:,1)-mean(temp(:,1));
                    clear temp;
                end
            end
            input = [];
            for i =1:length(direction)
                input = [input data{1,i}];
            end
            output = [];
            for i = 2:length(station)
                for j = 1:length(direction)
                    output = [output data{i,j}];
                end
            end
            % input = time_column(input); output = time_column(output);
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            function [x] = time_column(x)
                if size(x,1)>size(x,2)
                    x= x';
                end
            end
        end
    end
end

