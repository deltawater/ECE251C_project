clear all; close all; clc
% this code is to do MNEXT to the UCSD Geisel Library DATA
% Author: LIN SUN Date: Oct 6th, 2020
% University of California, San Diego
%% step 1: load data from station
station = {'lbba','lbno','lbse','lbsw'};
%e stands for east, n stands for north, z stands for vertical
dir = {'e','n','z'};
path = 'D:\UCSD PhD\GeiselProject\LibraryData\ConvertedData';

date.year = '2020'; date.month = '04'; date.day = '04'; date.hour = '01';
truncate= [321500 60*100+321500];
[input,output] = load_data(path, station, dir, date, truncate);
for i = 1:size(output,2)
    j = mod(i,3);
    if j == 0
        j =3;
    end
    output(:,i) = output(:,i) -input(:,j);
end
%% Run MNExT-ERA

table = 0;                    % 1 for printing table in stabilization diagram
guarda = 0;                   % 1 to save plots in jpg format
Fs = 100;                     % Sampling rate
perwin = 0.25;                % Length of the window (% of the time series)
win = 'hann';                 % Window in the PSD
overlap = 0.5;                % Overlapping in the PSD (%)
nfft = 2^16;                  % Length of the FFT
limtau = 500;                % Upper limit of the x-axis in cross-correlation plot
graf='yes';                   % 'yes' to plot
ndown = 1;                    % integer to downsample the cross-correlation functions
chan = 1:size(output,2);
ref = [1];
tipo = 'abs';
%% Do NEXT algorithm to get the cross correlation of the outputs
[output,Fs,Pxy,F,Rxy(:,:,:)] = MNExT(output,Fs,chan,ref,perwin,win,overlap,nfft,limtau,graf);
%% save the result
for i = 1:size(Rxy, 3)
    temp = Rxy(:,:,i);
    save(['Rxy' num2str(i) '.txt'], 'temp', '-ascii');
end