function [a,Fs,Pxy,F,Rxy]=MNExT(a,Fs,chan,ref,perwin,win,overlap,nfft,limtau,graf)
% DESCRIPTION: This code compute the auto and cross-correlation functions
% INPUT
%       a       : matrix of the output time histories
%       Fs      : original sampling rate
%       nFs     : integer to reduce the sampling rate of the data
%       chan    : channels considered in the analysis
%       ref     : reference channel (relative to chan)
%       perwin  : length of the window (percentage of the time series)
%       win     : type of window for the cpsd
%       overlap : percentage of overlapping
%       nfft    : lenght of the FFT
%       limtau  : maximum delay in plot of cross-correlation\
%       tit     : title of the plots
%       graf    : 'yes' to plot
%       imp     : 'yes' to save plot
%       tipo    : 'abs':absolute acceleration ; 'rel':relative acceleration
% OUTPUT
%       a       : corrected time histories (filtered and baseline)
%       Fs      : final sampling rate
%       Pxy     : cross-power spectral density
%       F       : frequency vector of Pxy
%       Rxy     : cross-correlation functions

nref=length(ref);               % # of reference channels

a=columna(a);
[~,col]=size(a);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vent = tukeywin(length(a),0.2);
for i=1:col
    a(:,i)=a(:,i).*vent;
end
tpo=time(a(:,1),Fs);
[~,col]=size(a);
lwin=round(perwin*length(a));    % Length of the window in PSD

vent=window(win,lwin);      % Window fucntion
%Pxy is the cross power spectrum density
Pxy=zeros(nfft,col,nref);  Rxy=zeros(nfft,col,nref);
for j=1:nref
    for i=1:col
        [Pxy(:,i,j),F]=cpsd(a(:,i),a(:,ref(j)),vent,round(overlap*lwin),nfft,Fs,'twosided');    
        Rxy(:,i,j)=(ifft(Pxy(:,i,j),nfft)*length(Pxy(:,1,1)));
    end
end
if isempty(chan)
    chan=1:col;
end
% Plots (time histories ; cross-power spectra ; cross-correlation)
if strcmp(graf,'yes')% graf: 'yes' to plot
    for i=1:col
        subplot(ceil(col/3),3,i);
        plot(tpo,a(:,i));
        ylabel(['Acc (ch.',num2str(chan(i)),')']);
        set(gca, 'FontName', 'Times New Roman');
        grid on;
        if i>(ceil(col/3)-1)*3   ; xlabel('Time (s)'); end
    end

    for j=1:nref
        figure;
        for i=1:col
            subplot(ceil(col/3),3,i); plot(F,abs(Pxy(:,i,j)),'Color', 'b'); xlim([0 25]);
            grid on;
            set(gca, 'FontName', 'Times New Roman')
            ylabel(['CPSD (c',num2str(chan(i)),'/c',num2str(chan(ref(j))),')']);
            if i>(ceil(col/3)-1)*3   ; xlabel('Frequency (Hz)'); end
        end
        print_plot('PSD.png',7,6, 800)
    end    
    for j=1:nref
        figure;
        for i=1:col
            subplot(ceil(col/3),3,i); plot(Rxy(:,i,j),'Color', 'b'); xlim([0 limtau]);
            ylabel(['R_X_Y (c',num2str(chan(i)),'/c',num2str(chan(ref(j))),')']);
            if i>(ceil(col/3)-1)*3   ; xlabel('\tau (sample)'); end
            xticks(0:limtau/5:limtau);
            set(gca, 'FontName', 'Times New Roman'); 
            grid on;
        end
        print_plot('cross correlation.png',7,6, 800)

    end
end


%% REFERENCES
%% ---------------------------------------------------------------------
function c=columna(a)
[m,n]=size(a);
if m < n
c=a.';
else
c=a;
end
return
%% ---------------------------------------------------------------------

function t=time(a,Fs)
%% ---------------------------------------------------------------------
if length(a)==1
t=(0:a-1)/Fs;
else
t=(0:(length(a)-1))/Fs;
end
t=t';
%% ---------------------------------------------------------------------

