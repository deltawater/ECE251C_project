function [tabu]=print_table(a,data,ini_minuto,fin_minuto,Fs,nombre_archivo,guarda)
% REFERENCES
%           impresion(in)
% SEP-02-2011
if isempty(fin_minuto) || fin_minuto==0
    minuto=length(a)/(Fs*60);
else
    minuto=fin_minuto;
end

leg_h = legend(gca);
leg_pos=get(leg_h,'Position'); %[left, bottom, width, height]
nombre_archivo = strrep(nombre_archivo, '_', '\_');
esp=cell(size(data,1),1);
for i=1:size(data,1)
    esp(i)={'  '};
end
%%% Table format
datos=[num2str(data(:,1),'%6.3f') char(esp) num2str(data(:,2),'%6.2f') ...
    char(esp) num2str(data(:,3),'%6.2f') char(esp) num2str(data(:,4), ...
    '%6.2f') char(esp) char(esp) num2str(data(:,5),'%6.0f')];
text(leg_pos(1)*1.42,leg_pos(2)*.85*(4/(max(size(data,1),4)))^.2, ...
    {nombre_archivo;' '; ...
    '     f        \sigma%    \beta%   \sigma%    N'; ...
    datos; ' '; ['Fs=' num2str(Fs) ' Hz']; ' '; ...
    ['duration=' sprintf('%1.1f',minuto) ' min']; ' '; ...
    ['t_i=' num2str(ini_minuto*60) ' seg.']}, ...
    'units','normalized','Interpreter','tex','FontSize',9, ...
    'HorizontalAlignment','left','FontName','Arial', ...
    'BackgroundColor',[1 1 1],'LineStyle','-', ...
    'Margin',4,'EdgeColor','black','LineWidth',.5);
if guarda==1
    set(gcf, 'PaperUnits', 'centimeters');
    width=25;
    height=18;
    set(gcf, 'PaperSize', [width height]);
    set(gcf, 'PaperPositionMode', 'manual');
    set(gcf, 'PaperPosition', [0 0 width height]);
    impresion([nombre_archivo,'.png'])
end

tabu=[data(:,1), data(:,3)]; %RAE


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               REFERENCES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ----------------------------------------------------------------------
function impresion(grafico)
% DESCRIPTION: Print a plot with the specified format 
% grafico : name of the file to print, format included (filename.tipo 'hola.jpg')
% options jpg eps ps win
% SEP-02-2011
i=max(find(grafico=='.')); 
tipo=grafico(i+1:length(grafico));
h = gcf;
xxx=0;
tempwin=0;
switch tipo
case 'png'
    printer_drv='-dpng';    printer_opt = '-r600';
case 'jpg' 
  printer_drv = '-djpeg100'; printer_opt = '-r300';
case 'eps' 
  printer_drv = '-depsc2'  ; printer_opt = '';
case  'ps' 
  printer_drv = '-dpsc2'   ; printer_opt = '-append';
case 'win' 
   print -dwinc;
   tempwin=1;
  %printer_drv = '-dwinc'   ; printer_opt = '';
case 'tiff' 
   printer_drv = '-dtiff'   ; printer_opt = '';  
   xxx=1;
end;   
if xxx
   grafico=grafico(1:end-1);
end
if ~isempty(tipo) & tempwin == 0 %% no entra si debe tirar solo a impresora.
   print(h,printer_drv,printer_opt,grafico);
end;
temp=orient;
%% ----------------------------------------------------------------------
