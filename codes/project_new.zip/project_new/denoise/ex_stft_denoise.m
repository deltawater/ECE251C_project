close all
clear
%% example 1
sample = 10000;
fs = 100;
t = (0:sample-1)/fs;
x1 = sin(10*t)*10;
x = x1+randn(size(x1))*20;
[x_denoise, t_denoise] = stft_denoise(x1,fs);
figure()
plot(t,x1,'r');
hold on;
plot(t_denoise, x_denoise,'color', 'b', 'LineStyle', '--');
%% example 2
clear all;
station = {'lbba','lbse'};
%e stands for east, n stands for north, z stands for vertical
dir = {'e','n','z'};
path = 'D:\UCSD PhD\GeiselProject\LibraryData\ConvertedData'; date.year = '2020'; date.month = '04'; date.day = '04'; date.hour = '01';
truncate= [320000 321500+6000];
Fs = 100; % sampling rate
ucsd = structure(path, date, station, dir, truncate, Fs);
[x_denoise, t_denoise] = stft_denoise(ucsd.output(:,1),Fs);
%%
function [x_denoise, t_denoise] = stft_denoise(x,fs, threshold)

samples = length(x);
t = (0:samples-1)/fs;
[s,f,t_stft]= stft(x,fs);

figure()
surf(t_stft,f,abs(s),'edgecolor','none');
shading flat;
axis tight;
view(0,90);
colormap default
hcol = colorbar;
xlabel('Time (sec)');
ylabel('Frequency (Hz)');
ylim([0 fs/2])
set(gca, 'FontName', 'Times New Roman')
set(hcol, 'FontName', 'Times New Roman', 'FontSize', 8);


if nargin  == 2
    threshold = input('Enter Threshold Values: ');
end

s(abs(s)<threshold) = 0;

[x_denoise, t_denoise] = istft(s,fs);

figure()
plot(t_denoise, x_denoise, 'color', 'r', 'LineWidth', 1.2)
hold on;
plot(t, x, 'color', 'blue', 'LineWidth', 1.2, 'LineStyle', '--');
ylim([min(x)*1.1 max(x)*1.1])
xlabel('Time (sec)');
ylabel('Accleration (m/sec^2)')
legend('Denoised signal', 'Original Signal')
set(gca, 'FontName', 'Times New Roman')

end